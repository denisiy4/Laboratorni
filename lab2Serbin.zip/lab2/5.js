const one = (name, country, weight) => {
	const bb = document.getElementById ('one')
	const td1 = document.createElement ('td')
	const td2 = document.createElement ('td')
	const td3 = document.createElement ('td')
	td1.appendChild(document.createTextNode(name))
	td2.appendChild(document.createTextNode(country))
	td3.appendChild(document.createTextNode(weight))
	bb.append(td1,td2,td3)
}
one("Еверест", "Непал", 8848)