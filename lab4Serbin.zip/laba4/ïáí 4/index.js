let my = {
    data(){
        return{
            description: "My basic App",
            userText: "My name is Denis Serbin"
        }
    }
}
Vue.createApp(my).mount("#app")