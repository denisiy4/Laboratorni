const reversed = eval(new String('2 + 3'));

function reverseStr(str) {
        return str.split("").reverse().join("");
    }
    console.log(reverseStr(reversed));