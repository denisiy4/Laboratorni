const http = require ('http')
http.createServer(function (req, res) {
    res.writeHead(200, {'context-Type': 'text/plain'});
    res.end('hello');
}).listen(8080);
console.log('Server running');

let requestHandler = (request, response) => {
    console.log(request.url)
    response.writeHead(200, {
    'Content-Type': 'text/html; charset=utf-8'
    })
    response.write(`Server started at port ${port}!`)
    response.end()
    }
    