console.log("31ІПЗ");
process.argv.forEach((val, index) => {
    console.log(`${index}: ${val}`);
  });


var dt = require('./reverse');