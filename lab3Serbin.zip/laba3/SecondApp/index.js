console.log("My second project");
var fs = require('fs');
let file = 'file.txt'
fs.readFile(file, 'utf8',(err,data) =>
{
if (err){
    console.log(err.message)
}
else{
    console.log(data)
}
})

let files = 'web.txt'
let fraza = 'JavaScript'
fs.writeFile(files, fraza, (err) =>
{
if (err){
    console.log(err.message)
}
else{
    console.log("+++")
}
})